﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MisApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            ShowItems();
        }
        private void ShowItems()
        {
            itemsCollection.ItemsSource = App.Db.GetItems();
        }

        private async void AddItemButton(object sender, EventArgs e)
        {
            string title = titleField.Text.Trim();
            string photo = photoField.Text.Trim();
            int price = Convert.ToInt32(priceField.Text.Trim());
            string isenable = isenableField.Text.Trim();
            if (title.Length<3)
            {
                await DisplayAlert("Ошибка", "Title min 3 sim", "OK");
                return;
            }
          
            else if (price<20)
            {
                await DisplayAlert("Ошибка", "Price min 20 sim", "OK");
                return;
            }
            else if (isenable.Length<5)
            {
                await DisplayAlert("Ошибка", "isenable min 5 sim", "OK");
                return;
            }
            Item item = new Item
            {
                Title = title,
                Photo=photo,
                Price=price,
                IsEnable=isenable,
            };
            App.Db.SaveItem(item);
            ShowItems();
            titleField.Text = "";
            photoField.Text = "";
            priceField.Text = "";
            isenableField.Text = "";
        }

       

        private  void DeleteItemButton(object sender, EventArgs e)
        {
            Item item = (Item)BindingContext;
            App.Db.DeleteItem(item);
            ShowItems();
        }
    }
}
