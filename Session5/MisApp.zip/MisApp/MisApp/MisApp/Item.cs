﻿using System;
using System.Collections.Generic;
using System.Text;
using SQLite;

namespace MisApp
{
   public class Item
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string Title { get; set; }
        public string Photo { get; set; }
        public int Price { get; set; }
        public string IsEnable { get; set; }

    }
}
